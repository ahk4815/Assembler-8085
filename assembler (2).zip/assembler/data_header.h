#ifndef SAMPLE
#define SAMPLE

void insert_data(int data,int i,int a[],int b[],int c[],int d[],int e[],int h[],int l[],int s[],int z[],int ac[],int p[],int cy[])
{
	if(i==160){a[0]=data;return;}
	if(i==161){b[0]=data;return;}
	if(i==162){c[0]=data;return;}
	if(i==163){d[0]=data;return;}
	if(i==164){e[0]=data;return;}
	if(i==165){h[0]=data;return;}
	if(i==166){l[0]=data;return;}
	int c1=0xFF;
	if(i==0)//ACI
	{   
		a[0]+=data+cy[0];
		if(a[0]>c1)
		{a[0]=a[0]%256;
		cy[0]=1;
		}
		else
		cy[0]=0;
		//put ac here
	}
	else if(i==17)//ADI
	{
	   a[0]+=data;	
	   if(a[0]>c1)
		{a[0]=a[0]%256;
		cy[0]=1;
		}
		else
		cy[0]=0;
		//put ac here
	}
	else if(i==26)//ANI
	{
	a[0]=a[0] & data;
	cy[0]=0;ac[0]=1;	
	}	
	else if(i==44)//CPI
	{
		int t=a[0]-data;
		if(data>a[0])
		{
		cy[0]=1;
		s[0]=1;
	    }
	    else
	    {
	    	cy[0]=0;
		}
		//put ac here
	}
	else if(i==218)//sbi
	{   	a[0]=a[0]-data-cy[0];
		if(a[0]<data+cy[0])cy[0]=1;
		else
		cy[0]=0;
	
		
	}
	else if(i==234)//sui
	{
		
		if(a[0]<data)cy[0]=1;
		else
		cy[0]=0;
		a[0]=a[0]-data;
	}
	else if(i==244)//xri
	{
		a[0]=a[0]^data;
		cy[0]=0;
		ac[0]=0;
	}
	else if(i==177)//ori
	{
		a[0]=a[0] | data ;
		cy[0]=0;
		ac[0]=0;
	}
	else
	{
	}
	if(a[0]==0x0)z[0]=1;
	else
	z[0]=0;
	
}



















#endif
