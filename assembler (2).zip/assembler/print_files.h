#ifndef PRINT
#define PRINT
#include<stdlib.h>
#include<stdio.h>
#include"opcode.h"
#include"sym_table.h"

int findsubstr2(char str1[],char st[])
{
	int len1=strlen(str1),len2=strlen(st);
	int i=0;
	for(i=0;i<len1-len2+1;i++)
	{    int j=i,f=0;
		for(;j<i+len2;j++)
		{
			if(str1[j]!=st[j-i]){
			f=1;break;}
		}
		if(f==0)return i;
	}
	return -1;
}
void show_pass1(){
	FILE* fh;
	fopen_s(&fh,"pass1_file.txt", "r");
	printf("show_pass1\n");
	//check if file exists
	if (fh == NULL){
	    printf("file does not exists");
	    return ;
	}
	
	int count=0;
	//read line by line
    char line[300];
	while (fgets(line, 300, fh) != NULL)  {
   printf("%s",line);


}
fclose(fh);
}
void show_pass1_file(struct opcodes optab[],struct symbol symtab[],int lsym,struct symbol temp_symtab[],int tsym[1])
{
	FILE *fp;
     fp = fopen("pass1_file.txt", "w+");
     
	FILE *fe;
     fe = fopen("pass2_file.txt", "w+");
     
    FILE* fh;
   // fopen_s(&fh,"withoutmacro.txt", "r");
    fopen_s(&fh,"preprocessed.txt", "r");
	if (fh == NULL){
	    printf("withoutmacro file does not exists");
	    return ;
	}
    char line[300];
	while (fgets(line,300, fh) != NULL)  
	{
		//search for opcode
		int i=0,pos,f=0;
		for(;i<246;i++){
			pos=findsubstr2(line,optab[i].name);
			if(pos!=-1)
			{f=1;
				pos+=strlen(optab[i].name);//start of data/address/label
				fprintf(fp,"%c%c  ",optab[i].opc[0],optab[i].opc[1]);
				fprintf(fe,"%c%c  ",optab[i].opc[0],optab[i].opc[1]);
			break;}
			 
		}
		if(f==0)printf("--------Opcode not found-------%s\n",line);
		else{
			if(optab[i].isdata!=-1)
			{
				fprintf(fp,"%c%c\n",line[pos],line[pos+1]);
				fprintf(fe,"%c%c\n",line[pos],line[pos+1]);
			}
		    else if(optab[i].isaddress!=-1)
			{
				fprintf(fp,"%c%c%c%c\n",line[pos],line[pos+1],line[pos+2],line[pos+3]);
				fprintf(fe,"%c%c%c%c\n",line[pos],line[pos+1],line[pos+2],line[pos+3]);
			}
			else if(optab[i].islabel!=-1)
			{
				char label[50];
				int l=0;
				line[strlen(line)-1]='\0';
				for(;pos<strlen(line) && line[pos]!=' ';pos++)
				{   
					label[l]=line[pos];
					l++;
				}
				label[l]='\0';
				int k= findsymbolpos(label,symtab,lsym);
				temp_symtab[tsym[0]].add=2000;
				strcpy(temp_symtab[tsym[0]].label,label);
			fprintf(fp,"%s\n",label);
			fprintf(fe,"#00000%X\n",tsym[0]);
			tsym[0]++;			
			}
			else
			{fprintf(fp,"\n");
			fprintf(fe,"\n");}
		}
	}
    fclose(fh);
    fclose(fp);
    fclose(fe);
    show_pass1();

}



void print_loader(){
	FILE* fh;
	fopen_s(&fh,"pass2.txt", "r");
	//check if file exists
	if (fh == NULL){
	    printf("file does not exists");
	    return ;
	}
	
	int count=0;
	//read line by line
    char line[300];
	while (fgets(line, 300, fh) != NULL)  {
   printf("%s \n",line);


}
fclose(fh);
}	  



void show_pass2_file(){
	FILE* fh;
	fopen_s(&fh,"pass2_file.txt", "r");
	//check if file exists
	if (fh == NULL){
	    printf("file does not exists");
	    return ;
	}
	
	int count=0;
	//read line by line
    char line[300];
	while (fgets(line, 300, fh) != NULL)  {
   printf("%s \n",line);


}
fclose(fh);
}	  












#endif
