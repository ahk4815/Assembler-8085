#ifndef OPCODE_
#define OPCODE_
#include<stdlib.h>
#include<stdio.h>
#include<string.h>


typedef struct opcodes{
	char name[50];
	char opc[2];
	int isdata;
	int islabel;
	int isaddress;
	int size;
}opcodes;






#endif
