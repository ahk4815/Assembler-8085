#ifndef HEX
#define HEX

typedef struct memory{
	int add;
	int val;
}memory;

void insert_address(int data,int i,int a[],int b[],int c[],int d[],int e[],int h[],int l[],struct memory mem[],int pos)
{
	int f1=data/256;
	int f2=data%256;
	if(i==89)//lda address
	{a[0]=mem[pos].val;
	}
	else if(i==219)//shld address
	{
		mem[pos].val=l[0];
		mem[pos+1].val=h[0];
	}
	else if(i==92)//lhld address
	{
		l[0]=mem[pos].val;
		h[0]=mem[pos+1].val;
	}
	else if(i==222)//sta adddress
	{
		mem[pos].val=a[0];
	}
	else if(i==93)//lxi b
	{
		b[0]=f1;
		c[0]=f2;
	}
	else if(i==94)//lxi d
	{
		d[0]=f1;
		e[0]=f2;
	}
	else if(i==95)//lxi h
	{
		h[0]=f1;
		l[0]=f2;
	}
	else if(i==96)//lxi sp
	{
	}
	else
	{
	}
}



#endif
