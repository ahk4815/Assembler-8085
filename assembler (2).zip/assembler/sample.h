#ifndef MACRO
#define MACRO
#include<stdlib.h>
#include<stdio.h>
#include<string.h>

int findsubstr1(char str1[],char st[])
{
	int len1=strlen(str1),len2=strlen(st);
	int i=0;
	for(i=0;i<len1-len2+1;i++)
	{    int j=i,f=0;
		for(;j<i+len2;j++)
		{
			if(str1[j]!=st[j-i]){
			f=1;break;}
		}
		if(f==0)return i;
	}
	return -1;
}
int pp=0;
char macro[50];
void getname(char line[])
{
	int i=0;
	for(;i<strlen(line);i++)
	{
		if((line[i]>='A' && line[i]<='Z')||(line[i]>='0' && line[i]<='9') )
		macro[i]=line[i];
		else
		break;
	}
	macro[i]='\0';
}
void preprocessing(char filename[])
{    
	 FILE* fh;
	fopen_s(&fh,filename, "r");
    FILE* fp;
	fopen_s(&fp,"macro.txt", "w+");
	    pp=0;
    char line[300];
    int f=0,z=0;
  	while (fgets(line,300, fh) != NULL)
	 {  if(f==0){
	 
	  	if(findsubstr1(line,"MACRO")!=-1)
	  	{f=1;
	  	z=1;
	       fgets(line,300, fh);
	       pp+=2;
		   getname(line);  		
	  	  }
	}
	else{
		pp++;
		if(findsubstr1(line,"MEND")!=-1)
		break;
		fprintf(fp,"%s",line);
		
	}
		}
		if(z==0)pp=0;
		fclose(fh);  
		fclose(fp);
}
void expandedfile(char filename[])
{   
	FILE* fh;
	fopen_s(&fh,filename, "r");
    FILE* fp;
	fopen_s(&fp,"preprocessed.txt", "w+");
    FILE* fs;
	fopen_s(&fs,"withoutmacro.txt", "w+");
   // printf("pp %d\n",pp);
	 char line[300];
     if(pp>0){
	 
	 while(fgets(line,300, fh) != NULL)
  	{  
  	  	pp--;
  	  	if(pp==0)break;
	  }
}
	while(fgets(line,300, fh) != NULL)
  	{
  		
  		if(findsubstr1(line,macro)!=-1)
  		{
  		   	FILE* fm;
        	fopen_s(&fm,"macro.txt", "r");
        	char l[300];
        	while(fgets(l,300, fm) != NULL)
  	        {
  	        	fprintf(fp,"%s",l);
  	        }
           fclose(fm);
			 	
		}
		  else
		  { 
		  	fprintf(fp,"%s",line);
		  	fprintf(fs,"%s",line);
		  }
  		
    }
	  fclose(fp);
	  fclose(fh);
	  fclose(fs);
	  
	  
}
void show_macro_file()
{       printf("\nThe preprocessed file is :\n");
		FILE* fh;
	fopen_s(&fh,"preprocessed.txt", "r");
	//check if file exists
	if (fh == NULL){
	    printf("file does not exists");
	    return ;
	}
	
	int count=0;
	//read line by line
    char line[300];
	while (fgets(line, 300, fh) != NULL)  {
   printf("%s \n",line);


}
fclose(fh);
}
void macros(char filename[])
{
		 FILE* fh;
	fopen_s(&fh,filename, "r");
    char line[300];
    int f=0;
  	while (fgets(line,300, fh) != NULL)
	 { if(findsubstr1(line,"MACRO")!=-1)
	 {f=1;
	 }
}
	  	fclose(fh);  
if(f==1)
{
//	printf("macro present\n");
preprocessing(filename);
expandedfile(filename);
}
else
{
	 FILE* fh;
	fopen_s(&fh,filename, "r");
	 FILE* fp;
	fopen_s(&fp,"preprocessed.txt", "w+");
    char line[300];
    int f=0;
  	while (fgets(line,300, fh) != NULL)
	{
	fprintf(fp,"%s",line); 
	}
	  	fclose(fh); 
	  	fclose(fp);
	  	
	  	FILE* f2;
	fopen_s(&f2,filename, "r");
	 FILE* f3;
	fopen_s(&f3,"withoutmacro.txt", "w+");
    f=0;
	while (fgets(line,300, f2) != NULL)
	{
	fprintf(f3,"%s",line); 
	}
	  	fclose(f2); 
	  	fclose(f3);

}
show_macro_file();
}

#endif
