#ifndef SYMTAB
#define SYMTAB
#include<stdlib.h>
#include<stdio.h>
#include<string.h>

typedef struct symbol{
	char label[50];
	int add;
}symbol;

int findsymbolpos(char st[],struct symbol symtab[],int lsym)
{
	int len=strlen(st);
	int i=0;
	for(;i<lsym;i++)
	{
		if(strcmp(st,symtab[i].label)==0)
		{   
			return i;
		}
	}
	return -1;
}

void show_tempsymtab(struct symbol temp_symtab[],int tsym[1])
{
	int i=0;
	printf("POSITION   LABEL NAME\n");
	for(;i<tsym[0];i++)
	{
		printf("%d          %s\n",i,temp_symtab[i].label);
	}
}










#endif
