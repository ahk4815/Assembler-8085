#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"sample.h"
#include"sample2.h"
/*struct cse{
	int x;
}roll[20];
*/
struct cse roll[20];
int main()
{
	preprocessing();
	expandedfile();
	/*char a='1';
	char b='A';
	FILE* fp;
	fp=fopen("conversion.txt","w");
	fprintf(fp,"%c%c",a,b);
	fclose(fp);
	int x;
	FILE* fh;
	fh=fopen("conversion.txt","r");
	fscanf(fh,"%X",&x);
	fclose(fh);
	
//	printf("%X %d",x,x);
int x1=0x3;
int y=0x1;
int z=y-x1;
printf("%X %X\n",z,x1-y);
 tee(roll);
   int i=0;
  for(;i<20;i++)
  {
  //	printf("%d\n",roll[i].x);
  }
  int x=0x10;
  int y=0x5A;
  int z=x*256 + y;
  //printf("%X\n",z);

x=0XAB;
y=0xCD;
y=(~y)+0x1;
printf("%X\n",x+y);
*/

 






return 0;
}
