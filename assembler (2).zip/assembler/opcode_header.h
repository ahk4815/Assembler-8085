#ifndef OPCODE
#define OPCODE
#include"memory.h"


void mov_instruction(char f,char t,int a[],int b[],int c[],int d[],int e[],int h[],int l[],struct memory mem[],int y)
{
	int value;
	if(t=='A')value=a[0];
	else if(t=='B')value=b[0];
	else if(t=='C')value=c[0];
	else if(t=='D')value=d[0];
	else if(t=='E')value=e[0];
	else if(t=='H')value=h[0];
	else if(t=='L')value=l[0];
	else//t==M
	{
		value=mem[y].val;
	}
	
	if(f=='A')a[0]=value;
	else if(f=='B')b[0]=value;
	else if(f=='C')c[0]=value;
	else if(f=='D')d[0]=value;
	else if(f=='E')e[0]=value;
	else if(f=='H')h[0]=value;
	else if(f=='L')l[0]=value;
	else//t==M
	{
		mem[y].val=value;
	}
	
}
void arithmetic(char ch,int i,int a[],int b[],int c[],int d[],int e[],int h[],int l[],struct memory mem[],int s[],int z[],int ac[],int p[],int cy[],int value)
{   if(i>=1 && i<=16){
    
	int c1=0xFF;
	int carry;
	if(i>=1 && i<=8)carry=cy[0];
	if(i>=9 && i<=16)carry=0;
	if(ch=='A')carry+=a[0];
	else if(ch=='B')carry+=b[0];
	else if(ch=='C')carry+=c[0];
	else if(ch=='D')carry+=d[0];
	else if(ch=='E')carry+=e[0];
	else if(ch=='H')carry+=h[0];
	else if(ch=='L')carry+=l[0];
	else if(ch=='M')carry+=value;
	else{return;}
	
	a[0]+=carry;
	if(a[0]>c1)
		{a[0]=a[0]%256;
		cy[0]=1;
		}
		else
		cy[0]=0;
		
		if(ac[0]==0x0)z[0]=1;
		else
		z[0]=0;
	return;
    }
    if(i>=18 && i<=25)
    {   int carry;
	    if(ch=='A')carry=a[0];
    	else if(ch=='B')carry=b[0];
		else if(ch=='C')carry=c[0];
		else if(ch=='D')carry=d[0];
		else if(ch=='E')carry=e[0];
		else if(ch=='H')carry=h[0];
		else if(ch=='L')carry=l[0];
		else if(ch=='M')carry=value;
		else
		{return;
		}
	    a[0]=a[0] & carry;
    	cy[0]=0;
    	
    	if(ac[0]==0x0)z[0]=1;
		else
		z[0]=0;
	return;
	}
	if(i>=32 && i<39)
	{
		int carry;
		if(ch=='A')carry=a[0];
    	else if(ch=='B')carry=b[0];
		else if(ch=='C')carry=c[0];
		else if(ch=='D')carry=d[0];
		else if(ch=='E')carry=e[0];
		else if(ch=='H')carry=h[0];
		else if(ch=='L')carry=l[0];
		else if(ch=='M')carry=value;
		else
		{return;
		}
		
		if(a[0]>carry){cy[0]=0;s[0]=0;z[0]=0;
		}
		else if(a[0]<carry){cy[0]=1;s[0]=1;z[0]=0;
		}
		else
		{cy[0]=0;s[0]=0;z[0]=1;
		}
		return;
	}
	if(i==30)
	{
		a[0]=~a[0];return;
	}
	if(i==31)
	{cy[0]=~cy[0];return;
	}
    
	return;
}

/*
if(a[0]>c1)
		{a[0]=a[0]%256;
		cy[0]=1;
		}
		*/

int convert2(int d)
{
	FILE* fp;
	fp=fopen("conversion2.txt","w");
	fprintf(fp,"%d",d);
	fclose(fp);
	int x1;
	FILE* fh;
	fh=fopen("conversion2.txt","r");
	fscanf(fh,"%d",&x1);
	fclose(fh);
	return x1;
}


void arithmetic2(int i,int a[],int b[],int c[],int d[],int e[],int h[],int l[],struct memory mem[],int s[],int z[],int ac[],int p[],int cy[],int y)
{
	if(i>=52 && i<=59)//DCR A-M
	{
		if(i==52)// A
		{
			a[0]-=1;
			if(a[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==53)// B
		{
			b[0]-=1;
			if(b[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==54) // c
		{
			c[0]-=1;
			if(c[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==55)// d
		{
			d[0]-=1;
			if(d[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==56)// e
		{
			e[0]-=1;
			if(e[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==57)//h
		{
			h[0]-=1;
			if(h[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==58)//l
		{
			l[0]-=1;
			if(l[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==59)
		{
			mem[y].val-=1;
			if(mem[y].val==0)z[0]=1;
			else
			z[0]=0;
		}
	}
	if(i>=68 && i<=75)// INR r
	{
		if(i==68)// A
		{
			a[0]+=1;
			if(a[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==69)// B
		{
			b[0]+=1;
			if(b[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==70) // c
		{
			c[0]+=1;
			if(c[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==71)// d
		{
			d[0]+=1;
			if(d[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==72)// e
		{
			e[0]+=1;
			if(e[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==73)//h
		{
			h[0]+=1;
			if(h[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==74)//l
		{
			l[0]+=1;
			if(l[0]==0)z[0]=1;
			else
			z[0]=0;
		}
		if(i==75)
		{
			mem[y].val+=1;
			if(mem[y].val==0)z[0]=1;
			else
			z[0]=0;
		}
		
	}
	if(i==60)//DCX B
	{
		int a1=b[0];
		a1=a1*256;
		a1+=c[0];
		a1-=1;
		b[0]=a1/256;
		c[0]=a1%256;
	}
	if(i==61)//DCX D
	{
		int a1=d[0];
		a1=a1*256;
		a1+=e[0];
		a1-=1;
		d[0]=a1/256;
		e[0]=a1%256	;	
	}
	if(i==62)//DCX H
	{
		int a1=h[0];
		a1=a1*256;
		a1+=l[0];
		a1-=1;
		h[0]=a1/256;
		l[0]=a1%256;
		
	}
	if(i==63)//DCX SP
	{
		
	}
	// now INX
	if(i==76)//INX B
	{
		int a1=b[0];
		a1=a1*256;
		a1+=c[0];
		a1+=1;
		b[0]=a1/256;
		c[0]=a1%256;
	}
	if(i==77)//INX D
	{
		int a1=d[0];
		a1=a1*256;
		a1+=e[0];
		a1+=1;
		d[0]=a1/256;
		e[0]=a1%256	;	
	}
	if(i==78)//INX H
	{
		int a1=h[0];
		a1=a1*256;
		a1+=l[0];
		a1+=1;
		h[0]=a1/256;
		l[0]=a1%256;
		
	}
	if(i==79)//INX SP
	{
		
	}
	
	if(i>=48 && i<=51)//DAD
	{   int hl=h[0];
		hl=hl*256;
		hl+=l[0];
		if(i==48)//DAD B
		{
		int bc=b[0];
		bc=bc*256;
		bc+=c[0];
		hl+=bc;
		}
		if(i==49)//DAD D
		{
		int de=d[0];
		de=de*256;
		de+=e[0];
		hl+=de;	
		}
		if(i==50)//DAD H
        {
        hl=hl+hl;
		} 		
		if(i==51)//DAD sp
		{//to be filled
		}
		h[0]=hl/256;
		l[0]=hl%256;
	}
	
}













#endif
