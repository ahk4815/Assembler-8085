#ifndef SAMPLE2
#define SAMPLE2
#include"sample.h"
#include<stdlib.h>
/*
typedef struct cse{
	int x;
}cse;
*/
void pee(struct cse roll[20])
{   
int i=0;
for(;i<20;i++)
roll[i].x=i+2;
}

void tee(struct cse roll[20])
{
	pee(roll);
}
int yee(int d)
{
	FILE* fp;
	fp=fopen("conversion2.txt","w");
	fprintf(fp,"%d",d);
	fclose(fp);
	int x1;
	FILE* fh;
	fh=fopen("conversion2.txt","r");
	fscanf(fh,"%d",&x1);
	fclose(fh);
	return x1;
}

#endif
